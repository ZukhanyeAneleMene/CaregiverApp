/**
 * This is my POJO CLASS
 * @author Zukhanye Anele Mene 21940427
 * Date: 09 August 2023
 */

package za.ac.cput.tut1.caregiver.Domain;


public class Caregiver {
    
       private String caregiverCode;
       private String firstName;
       private String lastName;
       private String caregiverType;
       private boolean hasResource;

    // CONSTRUCTORS
    public Caregiver(String caregiverType) {
        this.caregiverType = caregiverType;
    }

    public Caregiver(String caregiverCode, String firstName, String lastName, String caregiverType, boolean hasResource) {
        this.caregiverCode = caregiverCode;
        this.firstName = firstName;
        this.lastName = lastName;
        this.caregiverType = caregiverType;
        this.hasResource = hasResource;
    }

    public String getCaregiverCode() {
        return caregiverCode;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getCaregiverType() {
        return caregiverType;
    }

    public boolean getHasResource() {
        return hasResource;
    }

    public void setCaregiverCode(String caregiverCode) {
        this.caregiverCode = caregiverCode;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setCaregiverType(String caregiverType) {
        this.caregiverType = caregiverType;
    }

    public void setHasResource(boolean hasResource) {
        this.hasResource = hasResource;
    }

    @Override
    public String toString() {
        return "Caregiver{" + "caregiverCode=" + caregiverCode + ", firstName=" + firstName + ", lastName=" + lastName + ", caregiverType=" + caregiverType + ", hasResource=" + hasResource + '}';
    }


}
