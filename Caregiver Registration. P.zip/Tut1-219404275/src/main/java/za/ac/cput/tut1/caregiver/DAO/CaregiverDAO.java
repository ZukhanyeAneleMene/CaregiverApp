
package za.ac.cput.tut1.caregiver.DAO;

/**
  RaceDao.java
 * this is my dao class
 * @author 219404275 Zukhanye Anele Mene
 */ 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import za.ac.cput.tut1.caregiver.Domain.Caregiver;
import za.ac.cput.tut1.caregiver.Connection.ConnectionDB;

public class CaregiverDAO {
    
    private Connection con;
    private Statement stmnt;
    private PreparedStatement pstmnt;
    
    public CaregiverDAO(){
        try{
            this.con = ConnectionDB.derbyConnection();
        }catch(Exception e){
            System.out.println("error ");
        }
    }
    
    public Caregiver save(Caregiver caregiver){
      int ok;
      String sql = "INSERT INTO CAREGIVERS(caregivercode, firstname, lastname, caregivertypename, hasresources) VALUES('%s', '%s', '%s', '%s', '%s')";
      try{
          sql = String.format(sql, caregiver.getCaregiverCode(), caregiver.getFirstName(), caregiver.getLastName(), caregiver.getCaregiverType(), caregiver.getHasResource());
          System.out.println("sql:"+ sql);
          stmnt = this.con.createStatement();
          ok = stmnt.executeUpdate(sql);
          if(ok > 0){
              return caregiver;
          }else{
              return null;
          }
      }catch(SQLException hayke){
                  System.out.println("Error has occured in your sql query"+ hayke);
         }catch(Exception yoh){
                  System.out.println("Error has occured now we dont know"+ yoh);
         }finally{
          try{
             if(stmnt != null){
              stmnt.close(); 
          }
          
          }catch(Exception e){
              System.out.println("Error has occured"+ e);    
           }
      }
      return null;
    }
   
    
  public ArrayList<Caregiver> getCombo(){
        ArrayList<Caregiver> comboList = new ArrayList();
        try{  
        String getAllSQL = "SELECT CAREGIVERTYPENAME FROM CAREGIVERTYPES";
        pstmnt = this.con.prepareStatement(getAllSQL);
        ResultSet rs = pstmnt.executeQuery();
        if(rs != null){
            while(rs.next()){
                comboList.add(new Caregiver(rs.getString(1)));
            }
            rs.close();
        }
        }catch(SQLException sql){
           System.out.println("Error has occured"+ sql);
         }catch(Exception e){
                  System.out.println("Error has occured"+ e);
         }finally{
          try{
             if(pstmnt != null){
              pstmnt.close(); 
          }   
    }catch(Exception e){
              System.out.println("Error has occured"+ e);    
           } 
          }
        return comboList;
       
  }
}
