/**
 * This is my DBConnection class
 * @author Zukhanye Anele Mene 219404275
 * Date: 09 August 2023
 */

package za.ac.cput.tut1.caregiver.Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionDB {
    
    public static Connection derbyConnection() throws SQLException {

        // Driver Manager
      String DATABASE_URL = "jdbc:derby://localhost:1527/219404275CaregiversDB";
      String dbUsername   = "administrator";
      String dbPassword   = "password";

      // Call getConnection method
      Connection con = DriverManager.getConnection(DATABASE_URL, dbUsername, dbPassword);
      return con;
    }
}

