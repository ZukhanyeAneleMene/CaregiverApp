/**
 * CaregiverRegistration.java
 * This class creates the gui and calls the necessary functionality to store the information in the database
 * @author Zukhanye Anele and Mene (219404275)
 * Date: 15 August 2023
 */
package za.ac.cput.tut1.caregiver.Gui;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import za.ac.cput.tut1.caregiver.DAO.CaregiverDAO;
import za.ac.cput.tut1.caregiver.Domain.Caregiver;

public class CaregiverRegistration extends JFrame implements ActionListener {
    private JPanel panelNorth;
    private JPanel panelCenter, panelRB1, panelRB2;
    private JPanel panelSouth;
    
    private JLabel lblHeading;
    
    private JLabel lblCaregiverCode;
    private JTextField txtCaregiverCode;
        
    private JLabel lblFirstName;
    private JTextField txtFirstName;
        
    private JLabel lblLastName;
    private JTextField txtLastName;
        
    private JLabel lblCaregiverTypeName;
    private JComboBox cboCaregiverTypeName;
    
    private JLabel lblHasResources;
    private JRadioButton radHasResourcesYes;
    private JRadioButton radHasResourcesNo;
    
    private ButtonGroup resourcesGroup;
    
    private JButton btnSave, btnReset, btnExit;
    private Font ft1, ft2, ft3;
    
    Caregiver  caregiver;
    CaregiverDAO dao = new CaregiverDAO();
    ArrayList<Caregiver> caregiverList = new ArrayList();
    ArrayList<Caregiver> comboList = new ArrayList();
        
    public CaregiverRegistration() {
        super("Caregivers Registration App version 1.0");
        panelNorth = new JPanel();
        panelCenter = new JPanel();
        panelRB1 = new JPanel();
        panelRB2 = new JPanel();
        panelSouth = new JPanel();
        
        lblHeading = new JLabel("Caregiver Registration System");

        lblCaregiverCode = new JLabel("Caregiver Code: ");
        txtCaregiverCode = new JTextField();
        
        lblFirstName = new JLabel("First Name: ");
        txtFirstName = new JTextField();
        
        lblLastName = new JLabel("Last Name: ");
        txtLastName = new JTextField();
        
        cboCaregiverTypeName = new JComboBox<>();
        
      //  DefaultComboBoxModel<Object> comboBoxModel = new DefaultComboBoxModel<>();
       // cboCaregiverTypeName = new JComboBox<>(comboBoxModel);

        // Add items to the ComboBox
       // comboBoxModel.addElement("Volunteer");
       // comboBoxModel.addElement("Independent");
       // comboBoxModel.addElement("Proffesional");
        
        
        lblCaregiverTypeName = new JLabel("Caregiver Type: ");
        
                
        lblHasResources = new JLabel("Do you have caregiver equipment: ");
        radHasResourcesYes = new JRadioButton("Yes");
        radHasResourcesNo = new JRadioButton("No");
        
        resourcesGroup = new ButtonGroup();
        
        btnSave = new JButton("Save");
        btnReset = new JButton("Reset");
        btnExit = new JButton("Exit");
        
        ft1 = new Font("Arial", Font.BOLD, 32);
        ft2 = new Font("Arial", Font.PLAIN, 22);
        ft3 = new Font("Arial", Font.PLAIN, 24);

    }
    
    public void setGUI() {
        panelNorth.setLayout(new FlowLayout());
        panelCenter.setLayout(new GridLayout(5, 2));
        panelRB1.setLayout(new GridLayout(1, 2));
        panelRB2.setLayout(new GridLayout(1, 2));
        panelSouth.setLayout(new GridLayout(1, 3));
        
        panelNorth.add(lblHeading);
        lblHeading.setFont(ft1);
        lblHeading.setForeground(Color.yellow);
        panelNorth.setBackground(new Color(0, 106, 255));
            
        lblCaregiverCode.setFont(ft2);
        lblCaregiverCode.setHorizontalAlignment(JLabel.RIGHT);
        txtCaregiverCode.setFont(ft2);
        panelCenter.add(lblCaregiverCode);
        panelCenter.add(txtCaregiverCode);
                
        lblFirstName.setFont(ft2);
        lblFirstName.setHorizontalAlignment(JLabel.RIGHT);
        txtFirstName.setFont(ft2);
        panelCenter.add(lblFirstName);
        panelCenter.add(txtFirstName);
                
        lblLastName.setFont(ft2);
        lblLastName.setHorizontalAlignment(JLabel.RIGHT);
        txtLastName.setFont(ft2);
        panelCenter.add(lblLastName);
        panelCenter.add(txtLastName);
        
        lblCaregiverTypeName.setFont(ft2);
        lblCaregiverTypeName.setHorizontalAlignment(JLabel.RIGHT);
        cboCaregiverTypeName.setFont(ft2);
        panelCenter.add(lblCaregiverTypeName);
        panelCenter.add(cboCaregiverTypeName);
        panelCenter.setBackground(new Color(36, 145, 255));
        
        lblHasResources.setFont(ft2);
        lblHasResources.setHorizontalAlignment(JLabel.RIGHT);
        radHasResourcesYes.setFont(ft2);
        radHasResourcesYes.setHorizontalAlignment(JRadioButton.CENTER);
        radHasResourcesYes.setBackground(new Color(36, 145, 255));
        radHasResourcesNo.setFont(ft2);
        radHasResourcesNo.setHorizontalAlignment(JRadioButton.LEFT);
        radHasResourcesNo.setBackground(new Color(36, 145, 255));
        radHasResourcesYes.setSelected(true);
        
        resourcesGroup.add(radHasResourcesYes);
        resourcesGroup.add(radHasResourcesNo);
        
        panelCenter.add(lblHasResources);      
        panelRB1.add(radHasResourcesYes);
        panelRB1.add(radHasResourcesNo);
        panelCenter.add(panelRB1);
        
        btnSave.setFont(ft3);
        btnReset.setFont(ft3);
        btnExit.setFont(ft3);
        panelSouth.add(btnSave);
        panelSouth.add(btnReset);
        panelSouth.add(btnExit);
        
        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        btnSave.addActionListener(this);
        btnReset.addActionListener(this);
        btnExit.addActionListener(this);
        
        this.setSize(600, 600);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        
        comboList = dao.getCombo();
           for (int i = 0; i < comboList.size(); i++) {
               String cmb =  comboList.get(i).getCaregiverType();
               cboCaregiverTypeName.addItem(cmb);
               
        
    }
    }
        
    private void resetForm() {
        txtCaregiverCode.setText("");
        txtFirstName.setText("");
        txtLastName.setText("");
        cboCaregiverTypeName.setSelectedIndex(0);
        radHasResourcesYes.setSelected(true);
        txtCaregiverCode.requestFocus();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource()==btnSave){
            String caregiverCode = txtCaregiverCode.getText();
            String firstName = txtFirstName.getText();
            String lastName = txtLastName.getText();
            String caregiverType = cboCaregiverTypeName.getSelectedItem().toString();
            boolean hasResource = radHasResourcesYes.isSelected();
            
           caregiver = new Caregiver (caregiverCode, firstName, lastName, caregiverType, hasResource);
           dao.save(caregiver);
           
       JOptionPane.showMessageDialog(null, "Successfull, Subject added ");
      
    }
          if(e.getSource()==btnReset){
            resetForm();
           
           }
         if (e.getSource()== btnExit) {
            
            System.exit(0);
        }
    }
    
     public static void main(String[] args) {
        new CaregiverRegistration().setGUI();
    }
}
